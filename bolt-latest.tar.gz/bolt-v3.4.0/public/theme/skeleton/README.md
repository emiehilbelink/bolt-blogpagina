Bolt Skeleton Theme
===================

Skeleton is a minimal theme for Bolt. It has the bare bones functionality of
what you commonly expect from a template, without all the bells and whistles.

Features:

  - Simple design, function over form.
  - Uses [Sakura](https://github.com/oxalorg/sakura) as a minimal CSS theme.
  - No Javascript.